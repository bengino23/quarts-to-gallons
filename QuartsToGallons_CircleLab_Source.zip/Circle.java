public class Circle {
    private double radius;

    // Constructor
    public Circle(double radius) {
        setRadius(radius); // use validation in setter
    }

    // Accessor
    public double getRadius() {
        return radius;
    }

    // Mutator with validation (prevents negative radius)
    public void setRadius(double radius) {
        if (radius < 0) {
            radius = 0; // simple handling: force to 0
        }
        this.radius = radius;
    }

    // Returns area = pi * r^2
    public double getArea() {
        return Math.PI * radius * radius;
    }

    // Returns circumference = 2 * pi * r
    public double getCircumference() {
        return 2 * Math.PI * radius;
    }
}
