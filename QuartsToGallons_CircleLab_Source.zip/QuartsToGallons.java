public class QuartsToGallons {
    public static void main(String[] args) {

        // Named constant: a value that should not change during program execution
        final int QUARTS_PER_GALLON = 4;

        // Given input value
        int quartsNeeded = 18;

        // / gives the number of full groups (full gallons)
        int gallons = quartsNeeded / QUARTS_PER_GALLON;

        // % gives the leftover amount after grouping (remaining quarts)
        int quarts = quartsNeeded % QUARTS_PER_GALLON;

        // Exact required output format
        System.out.println("A job that needs " + quartsNeeded +
                " quarts requires " + gallons +
                " gallons plus " + quarts + " quarts.");
    }
}
