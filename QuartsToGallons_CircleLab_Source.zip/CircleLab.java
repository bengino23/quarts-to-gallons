public class CircleLab {
    public static void main(String[] args) {

        // Create Circle object with radius 5.0
        Circle c = new Circle(5.0);

        // Print values with two decimals
        System.out.printf("radius: %.2f%n", c.getRadius());
        System.out.printf("area: %.2f%n", c.getArea());
        System.out.printf("circumference: %.2f%n%n", c.getCircumference());

        // Update radius to 8.5
        c.setRadius(8.5);

        // Print updated values
        System.out.printf("radius: %.2f%n", c.getRadius());
        System.out.printf("area: %.2f%n", c.getArea());
        System.out.printf("circumference: %.2f%n", c.getCircumference());
    }
}
